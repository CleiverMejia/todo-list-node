import type { Request, Response } from "express";
import { GroupService } from "./group.service";
export declare class GroupController {
    private groupService;
    constructor(groupService?: GroupService);
    findAll: (req: Request, res: Response) => void;
    findOne: (req: Request, res: Response) => void;
    create: (req: Request, res: Response) => void;
    update: (req: Request, res: Response) => void;
    delete: (req: Request, res: Response) => void;
}
//# sourceMappingURL=group.controller.d.ts.map