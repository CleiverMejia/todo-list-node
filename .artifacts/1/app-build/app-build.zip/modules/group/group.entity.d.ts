export interface Group {
    id: number;
    uid: number;
    name: string;
}
//# sourceMappingURL=group.entity.d.ts.map