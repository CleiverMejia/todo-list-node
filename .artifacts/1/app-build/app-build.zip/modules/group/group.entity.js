export {};
//# sourceMappingURL=group.entity.js.map