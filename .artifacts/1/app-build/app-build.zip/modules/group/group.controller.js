import { GroupService } from "./group.service";
export class GroupController {
    groupService;
    constructor(groupService = new GroupService()) {
        this.groupService = groupService;
    }
    findAll = (req, res) => {
        try {
            const { uid } = req.params;
            const groups = this.groupService.findAll(+uid);
            res.status(200).json({
                success: true,
                data: groups,
            });
        }
        catch {
            res.status(500).json({
                success: false,
                error: "Internal server error",
            });
        }
    };
    findOne = (req, res) => {
        try {
            const { uid, id } = req.params;
            const group = this.groupService.findOne(+uid, +id);
            res.status(200).json({
                success: true,
                data: group,
            });
        }
        catch (error) {
            if (error instanceof Error && error.message.startsWith("Group")) {
                res.status(404).json({
                    success: false,
                    error: "Group not found",
                });
                return;
            }
            res.status(500).json({
                success: false,
                error: "Internal server error",
            });
        }
    };
    create = (req, res) => {
        try {
            const { uid } = req.params;
            if (!req.body || !req.body.name) {
                res.status(400).json({
                    success: false,
                    error: "Bad request",
                });
                return;
            }
            const { name } = req.body;
            const group = this.groupService.create(+uid, name);
            res.status(201).json({
                success: true,
                data: group,
            });
        }
        catch {
            res.status(500).json({
                success: false,
                error: "Internal server error",
            });
        }
    };
    update = (req, res) => {
        try {
            const { uid, id } = req.params;
            if (!req.body || !req.body.name) {
                res.status(400).json({
                    success: false,
                    error: "Bad request",
                });
                return;
            }
            const { name } = req.body;
            const group = this.groupService.update(+uid, +id, name);
            res.status(200).json({
                success: true,
                data: group,
            });
        }
        catch (error) {
            if (error instanceof Error && error.message.startsWith("Group")) {
                res.status(404).json({
                    success: false,
                    error: "Group not found",
                });
                return;
            }
            res.status(500).json({
                success: false,
                error: "Internal server error",
            });
        }
    };
    delete = (req, res) => {
        try {
            const { uid, id } = req.params;
            this.groupService.remove(+uid, +id);
            res.status(200).json({
                success: true,
            });
        }
        catch {
            res.status(500).json({
                success: false,
                error: "Internal server error",
            });
        }
    };
}
//# sourceMappingURL=group.controller.js.map