import type { Request, Response } from "express";
import { TaskService } from "./task.service";
export declare class TaskController {
    private taskService;
    constructor(taskService?: TaskService);
    findAll: (req: Request, res: Response) => void;
    findOne: (req: Request, res: Response) => void;
    create: (req: Request, res: Response) => void;
    update: (req: Request, res: Response) => void;
    delete: (req: Request, res: Response) => void;
}
//# sourceMappingURL=task.controller.d.ts.map