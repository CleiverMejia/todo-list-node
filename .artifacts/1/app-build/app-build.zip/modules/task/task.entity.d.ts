export interface Task {
    id: number;
    uid: number;
    title: string;
    content: string;
}
//# sourceMappingURL=task.entity.d.ts.map