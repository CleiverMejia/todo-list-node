import { UserService } from "./user.service";
export class UserController {
    userService;
    constructor(userService = new UserService()) {
        this.userService = userService;
    }
    findAll = (req, res) => {
        try {
            const users = this.userService.findAll();
            res.status(200).json({
                success: true,
                data: users,
            });
        }
        catch {
            res.status(500).json({
                success: false,
                error: "Internal server error",
            });
        }
    };
    findOne = (req, res) => {
        try {
            const { id } = req.params;
            const user = this.userService.findOne(+id);
            if (!user) {
                res.status(404).json({
                    success: false,
                    error: "User not found",
                });
                return;
            }
            res.status(200).json({
                success: true,
                data: user,
            });
        }
        catch {
            res.status(500).json({
                success: false,
                error: "Internal server error",
            });
        }
    };
    create = (req, res) => {
        try {
            if (!req.body || !req.body.name || !req.body.email) {
                res.status(400).json({
                    success: false,
                    error: "Bad request",
                });
                return;
            }
            const { name, email } = req.body;
            const user = this.userService.create(name, email);
            res.status(201).json({
                success: true,
                data: user,
            });
        }
        catch {
            res.status(500).json({
                success: false,
                error: "Internal server error",
            });
        }
    };
    update = (req, res) => {
        try {
            const { id } = req.params;
            if (!req.body || !req.body.name || !req.body.email) {
                res.status(400).json({
                    success: false,
                    error: "Bad request",
                });
                return;
            }
            const { name, email } = req.body;
            const user = this.userService.update(+id, name, email);
            res.status(200).json({
                success: true,
                data: user,
            });
        }
        catch {
            res.status(500).json({
                success: false,
                error: "Internal server error",
            });
        }
    };
    delete = (req, res) => {
        try {
            const { id } = req.params;
            this.userService.remove(+id);
            res.status(200).json({
                success: true,
            });
        }
        catch {
            res.status(500).json({
                success: false,
                error: "Internal server error",
            });
        }
    };
}
//# sourceMappingURL=user.controller.js.map