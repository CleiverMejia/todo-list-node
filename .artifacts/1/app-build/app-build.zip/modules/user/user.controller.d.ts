import type { Request, Response } from "express";
import { UserService } from "./user.service";
export declare class UserController {
    private userService;
    constructor(userService?: UserService);
    findAll: (req: Request, res: Response) => void;
    findOne: (req: Request, res: Response) => void;
    create: (req: Request, res: Response) => void;
    update: (req: Request, res: Response) => void;
    delete: (req: Request, res: Response) => void;
}
//# sourceMappingURL=user.controller.d.ts.map