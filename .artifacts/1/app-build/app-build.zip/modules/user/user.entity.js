export {};
//# sourceMappingURL=user.entity.js.map