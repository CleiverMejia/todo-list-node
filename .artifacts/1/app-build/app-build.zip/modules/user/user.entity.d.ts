export interface User {
    id: number;
    name: string;
    email: string;
}
//# sourceMappingURL=user.entity.d.ts.map