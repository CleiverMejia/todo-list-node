import { TaskService } from "./modules/task/task.service";
import { UserService } from "./modules/user/user.service";
console.log(UserService);
console.log(TaskService);
//# sourceMappingURL=index.js.map